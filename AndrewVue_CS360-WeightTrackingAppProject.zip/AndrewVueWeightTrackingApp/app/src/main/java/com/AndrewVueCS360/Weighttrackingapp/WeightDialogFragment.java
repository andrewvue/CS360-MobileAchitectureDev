package com.AndrewVueCS360.Weighttrackingapp;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import androidx.fragment.app.DialogFragment;

import com.AndrewVueCS360.Weighttrackingapp.R;

public class WeightDialogFragment extends DialogFragment {

    // Host activity must implement
    public interface OnWeightEnteredListener {
        void onWeightEntered(String date, int weight);

        void onWeightEdited(String oldDate, String newDate, int weight);
    }

    private OnWeightEnteredListener mListener;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        // Get the layout inflater
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.add_edit_dialog, null);

        final EditText dateEditText = dialogView.findViewById(R.id.addDate);
        final EditText weightEditText = dialogView.findViewById(R.id.addWeight);

        if (getArguments().getBoolean("edit")) {
            dateEditText.setText(getArguments().getString("date"));
            weightEditText.setText(Integer.toString(getArguments().getInt("weight")));
        }

        // Inflate and set the layout for the dialog
        // Pass null as the parent view because its going in the dialog layout
        builder.setView(dialogView)
                // Add action buttons
                .setPositiveButton(R.string.assign, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {

                        String date = dateEditText.getText().toString();
                        String weight = weightEditText.getText().toString();
                        int finalValue = Integer.parseInt(weight);

                        if (getArguments().getBoolean("edit")) {
                            mListener.onWeightEdited(getArguments().getString("date"), date.trim(), finalValue);
                        } else {
                            mListener.onWeightEntered(date.trim(), finalValue);
                        }
                    }
                })
                .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        WeightDialogFragment.this.getDialog().cancel();
                    }
                });
        return builder.create();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mListener = (OnWeightEnteredListener) context;
    }
}