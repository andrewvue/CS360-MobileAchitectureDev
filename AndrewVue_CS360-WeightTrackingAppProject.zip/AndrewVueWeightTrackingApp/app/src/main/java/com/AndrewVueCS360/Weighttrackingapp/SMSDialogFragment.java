package com.AndrewVueCS360.Weighttrackingapp;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.DialogFragment;

import com.AndrewVueCS360.Weighttrackingapp.R;

public class SMSDialogFragment extends DialogFragment {

    // Host activity must implement
    public interface OnSMSApprovedListener {
    }

    private OnSMSApprovedListener mListener;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        // Get the layout inflater
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.sms_phone_dialog, null);

        final EditText editTextPhoneNumber = dialogView.findViewById(R.id.addPhoneNo);

        SharedPreferences sharedPref = getActivity().getPreferences(Context.MODE_PRIVATE);
        if(sharedPref.getInt("PhoneNumber", 0)!=0){
            int mPhoneNumber = sharedPref.getInt("PhoneNumber", 0);
            editTextPhoneNumber.setText(String.valueOf(mPhoneNumber));
        }

        // Inflate and set the layout for the dialog
        // Pass null as the parent view because its going in the dialog layout
        builder.setView(dialogView)
                // Add action buttons
                .setPositiveButton(R.string.assign, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        if (editTextPhoneNumber.length() == 10){
                            String mPhoneNumber = editTextPhoneNumber.getText().toString();
                            SharedPreferences sharedPref = getActivity().getPreferences(Context.MODE_PRIVATE);
                            SharedPreferences.Editor editor = sharedPref.edit();
                            editor.putInt("PhoneNumber", Integer.parseInt(mPhoneNumber));
                            editor.commit();
                        } else {
                            Toast.makeText(getContext(), "Entry must be 10 digit phone number, please try again", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        SMSDialogFragment.this.getDialog().cancel();
                    }
                });
        return builder.create();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mListener = (OnSMSApprovedListener) context;
    }
}